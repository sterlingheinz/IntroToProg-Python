#  When the program starts,
#  load each row of data from the ToDo.txt text file into a Python dictionary.(The data will be stored like a row in a table.)
#  Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.

#---------------------------------------------------------------------------------------------------

#   After you get the data in a Python dictionary,
#   Add the new dictionary “row” into a Python list object (now the data will be managed as a table).


print("Welcome to the To Do list program")


objFileName = "C:\_PythonClass\Module05\ToDo.txt"
strData = ""
dicTable = {}
dicRow1 = {"Task":"Clean House","Priority":"Low"}
dicRow2 = {"Task":"Pay Bills","Priority":"High"}
lstTable = [dicRow1,dicRow2]


while(True):
    print ("""
    Tasks Menu
    1) Load Task data
    2) Add a new task
    3) Remove an existing task
    4) Save Data to File
    5) Exit 
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

# 1 show lists
    if (strChoice.strip() == '1'):
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line
            lstData = strData.split(",")
            dicTable[lstData[0].strip()]= lstData[1].strip()
        objFile.close()
        print("To Do List\n----------------")
        for strKey, strValue in dicTable.items():
            print(strKey + " (" + strValue +")")
        continue


# 2 add tasks
    elif(strChoice.strip() == '2'):
        while (True):
            strTask = str(input("\nEnter a Task: "))
            strPriority = str(input("\nEnter the task priority: High or Low?"))
            dicTable[strTask] = strPriority
            print("Task Added!\n")
            if (input("\nPress enter to add another task, or type 'menu' to return to main menu.").lower() == "menu"): break
        continue


# 3 remove task
    elif(strChoice == '3'):


        for strKey, strValue in dicTable.items():
            print(strKey)
        strKeyRemove = input("Which task would you like to remove?")
        if(strKeyRemove in dicTable):
            del dicTable[strKeyRemove]
        else:
            print("Task not on list.")
        print("\nRemaining Tasks: ")
        for strKey, strValue in dicTable.items():
            print(strKey)
        continue


# 4 Save tasks to the ToDo.txt file
    elif(strChoice == '4'):

        objFile = open(objFileName, 'w')
        for strKey, strValue in dicTable.items():
            objFile.write(strKey + "," + strValue + "\n")
        objFile.close()

        print("Data saved!")
        continue


    elif (strChoice == '5'):

        break #and Exit the program


