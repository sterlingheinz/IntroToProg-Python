
## -- DATA -- ##

objFileName = "C:\_PythonClass\Module05\ToDo.txt"
strData = ""
dicRow = {}
lstTable = []
lstAnswer = None



## ----- PROCESSING ----- ##

# Opens To Do list and loads data into dictionary
objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",") # readline() reads a line of the data into 2 elements
    dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()


# Functions that operate from menu choices
def MenuChoice(X):

    Show = A
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
    return [Show]
    lstAnswer = MenuChoice()

    Add = B
    strTask = str(input("What is the task? - ")).strip()
    strPriority = str(input("What is the priority? [high|low] - ")).strip()
    dicRow = {"Task": strTask, "Priority": strPriority}
    lstTable.append(dicRow)
    print("Current Data in table:")
    for dicRow in lstTable:
        print(dicRow)
        #4a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        continue #to show the menu
    return [Add]
    lstAnswer = MenuChoice()

    Remove = C
    # 5a-Allow user to indicate which row to delete
    strKeyToRemove = input("Which TASK would you like removed? - ")
    blnItemRemoved = False  # Creating a boolean Flag
    intRowNumber = 0
    while (intRowNumber < len(lstTable)):
        if (strKeyToRemove == str(
                list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
            del lstTable[intRowNumber]
            blnItemRemoved = True
        # end if
        intRowNumber += 1
    # end for loop
    # 5b-Update user on the status
    if (blnItemRemoved == True):
        print("The task was removed.")
    else:
        print("I'm sorry, but I could not find that task.")

    # 5c Show the current items in the table
    print("******* The current items ToDo are: *******")
    for row in lstTable:
        print(row["Task"] + "(" + row["Priority"] + ")")
    print("*******************************************")
    return [Remove]
    lstAnswer = MenuChoice()

    Save = D
    # 5a Show the current items in the table
    print("******* The current items ToDo are: *****")
    return [Save]
    lstAnswer = MenuChoice()




## ---------- PRESENTATION ----------- ##

while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Option 1
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        print(lstAnswer[0])
        #print(MenuChoice[0])


    # Choice 2
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        print(lstAnswer[1])


    # Choice 3
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        print(lstAnswer[2])


    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print(lstAnswer[3])

    elif (strChoice == '5'):
        break  # and Exit the program


